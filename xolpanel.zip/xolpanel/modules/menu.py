from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("SSH Menu ","ssh"),
Button.inline("Trial SSH ","trial-ssh")],
[Button.inline("Vmess MANAGER ","vmess"),
Button.inline("Vless MANAGER ","vless")],
[Button.inline("Trojan MANAGER ","trojan"),
Button.inline("Shadowsocks MANAGER ]","shadowsocks")],
[Button.inline("CHECK VPS INFO ","info"),
Button.inline("OTHER SETTING","setting")],
[Button.url("Tele Group","https://t.me/JengkolTunneling12"),
Button.url("Wa Group ","https://chat.whatsapp.com/IYoQTkg2su619CBhTl7wxO")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Acces Denied", alert=True)
		except:
			await event.reply("Acces Denied")
	elif val == "true":
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Admin Panel Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» ⚡Beta Version:** `v1`
**» 🤖Bot By:** `@Dragon_Emperor999`

**━━━━━━━━━━━━━━━━**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
